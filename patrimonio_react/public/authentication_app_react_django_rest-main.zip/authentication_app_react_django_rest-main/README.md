# React/DjangoRF Authentication App

Authentication app using React and Django REST framework with session authentication.

## Installations

* backend
```
pip install djangorestframework
pip install django-cors-headers
```

* frontend
```
npm install axios
npm install react-bootstrap bootstrap
```
